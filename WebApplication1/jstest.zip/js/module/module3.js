﻿define('module3',[],function (require, exports) {

    exports.m3 = function () {
        alert("module3alert");
    }
});