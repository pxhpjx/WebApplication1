(function() {

  seajs.use('module/module1', function(a) {
    return a.init("coffee1");
  });

}).call(this);
