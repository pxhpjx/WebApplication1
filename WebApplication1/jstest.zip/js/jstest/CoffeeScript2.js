(function() {

  seajs.use(glo_initpath, function(init) {
    var $;
    $ = init;
    return $(function() {
      return alert($("#qwer")[0].innerHTML);
    });
  });

}).call(this);
